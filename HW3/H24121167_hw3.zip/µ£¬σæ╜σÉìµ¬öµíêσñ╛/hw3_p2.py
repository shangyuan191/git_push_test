f=str(input("Input polynomial: "))
n=int(input("Input the value of x: "))
l=[]
r=[]
h=[]
s=f.split("+")
i=0
while i<len(s):
    t=s[i].split("-")
    l.extend(t)
    i=i+1
i=0    
while i<len(l):
    k=l[i].split("*")
    r.extend(k)
    i=i+1
i=0
while i<len(r):
    e=r[i].split("^")
    a=n**e[1]
    h.extend(e)
    i=i+1
print(h)    

