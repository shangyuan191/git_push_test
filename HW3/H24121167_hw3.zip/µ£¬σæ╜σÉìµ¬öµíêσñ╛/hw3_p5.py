s=list(input("Input seqence of seats: "))
