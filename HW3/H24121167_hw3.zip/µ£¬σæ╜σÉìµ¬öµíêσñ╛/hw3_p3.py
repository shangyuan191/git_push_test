while True:
    x=input("Player x ")
    y=input("Player y ")
