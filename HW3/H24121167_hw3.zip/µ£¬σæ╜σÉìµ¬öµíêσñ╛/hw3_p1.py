n=int(input("Input the total number of students (n>0): "))
