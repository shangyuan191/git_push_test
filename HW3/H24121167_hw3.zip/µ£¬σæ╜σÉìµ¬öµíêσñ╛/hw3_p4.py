m=input("Enter index x,y,k (separated by whitespace): ")
